Credit: https://chewycereal.itch.io/spaceshipstarterpack
License: Public domain

Use the included colour pallete to apply to the materials to assign the colours to the assets.

If you're feeling generous, support these assets by crediting ChewyCereal in your project, but this is not mandatory.

A collection of 3D assets of original spaceships.

An easy to use collection with multiple different file formats (FBX, OBJ and GTLF 2) all ready to use in your projects. 

This pack contains:

2x Fighters
1x Small corvette
1x Luxury yacht
1x Personal spacecraft
1x Large medical frigate
1x Large shipping freighter
Each ship is designed to use 2 materials, an emissive and a normal material which are both already assigned to the correct faces. Simply replace the spaces with materials made in your game engine of choice using the included colour sheet.

All items included in this pack are available to use in personal, educational and commercial products.

